import pygame 
import random
import keyboard,time,math
from math import sqrt

def euclidean_distance(a, b):
	return sqrt(sum((e1-e2)**2 for e1, e2 in zip(a,b)))

def is_collision(rx,ry,ax1,ay1,ax2,ay2):
    PI=3.14
    slope1=(ay2-ay1)/(ax2-ax1)
    slope2=(ay2-ry)/(ax2-rx)
    c=math.atan(slope1)*180/PI
    d=math.atan(slope2)*180/PI
    if c>d:angle=c-d
    else: angle=d-c
    if angle>5: return True
    else: return False

pygame.init()  
white = (255, 255, 255)  
 
height = 570  
width = 400 

RED=[255,0,0]
GREEN=[0,255,0]
vy=10
  
display_surface = pygame.display.set_mode((height, width)) 




    
pygame.display.set_caption('Ai football')  
  
  
image = pygame.image.load(r'photos\ground.png') 

img_red1 = pygame.image.load(r'photos\redT.png') 
img_yellow1 = pygame.image.load(r'photos\yellow.png')

img_red2 = pygame.image.load(r'photos\redT.png') 
img_yellow2 = pygame.image.load(r'photos\yellow1.png')

img_red3 = pygame.image.load(r'photos\redT.png') 
img_yellow3 = pygame.image.load(r'photos\yellow2.png')

img_agent = pygame.image.load(r'photos\agent.png')
img_red4 = pygame.image.load(r'photos\redT.png') 
img_ball = pygame.image.load(r'photos\ball.png')  




  
# infinite loop   
while True:  
    try:
        
        if keyboard.is_pressed(' '):
            
            display_surface.fill(white)  
            display_surface.blit(image, (0, 0)) 
            #blit(source,dest,area=None,special_flags=0) 


            red1_xcor =random.randrange(90,400)
            red1_ycor =random.randrange(100,120)

            red2_xcor =random.randrange(20,200)
            red2_ycor =random.randrange(180,280)

            red3_xcor =random.randrange(400,470)
            red3_ycor =random.randrange(225,290)

            red4_xcor =random.randrange(20,270)
            red4_ycor =random.randrange(180,190)
            
            yellow1_xcor = random.randrange(90,400)
            yellow1_ycor =random.randrange(25,70)

            yellow2_xcor = random.randrange(100,300)
            yellow2_ycor = random.randrange(160,280)

            yellow3_xcor = random.randrange(200,400)
            yellow3_ycor = random.randrange(160,280)

            ball_xcor=275
            ball_ycor=325
            
            
            display_surface.blit(img_red1, (red1_xcor,red1_ycor))
            display_surface.blit(img_red2, (red2_xcor,red2_ycor))
            display_surface.blit(img_red3, (red3_xcor,red3_ycor))
            display_surface.blit(img_red4, (red4_xcor,red4_ycor))

            display_surface.blit(img_yellow1, (yellow1_xcor,yellow1_ycor))#(100, 70))
            display_surface.blit(img_yellow2, (yellow2_xcor,yellow2_ycor))
            display_surface.blit(img_yellow3, (yellow3_xcor,yellow3_ycor))
            display_surface.blit(img_agent, (260,350))

            display_surface.blit(img_ball, (ball_xcor,ball_ycor)) 
            print("Ai is activated")

            print("Calculating euclidean distance......")
            distance1 = euclidean_distance([260,350],[yellow2_xcor,yellow2_ycor])
            distance2 = euclidean_distance([260,350],[yellow3_xcor,yellow3_ycor])
            distance3 = euclidean_distance([yellow2_xcor,yellow2_ycor],[yellow3_xcor,yellow3_ycor])
            distance4 = euclidean_distance([yellow2_xcor,yellow2_ycor],[yellow1_xcor,yellow1_ycor])
            distance5 = euclidean_distance([yellow3_xcor,yellow3_ycor],[yellow1_xcor,yellow1_ycor])
            distance6 = euclidean_distance([260,350],[yellow1_xcor,yellow1_ycor])
            distance7 = euclidean_distance([300,20],[yellow1_xcor,yellow1_ycor])
            distance8 =  euclidean_distance([300,20],[yellow2_xcor,yellow2_ycor])
            distance9 =  euclidean_distance([300,20],[yellow3_xcor,yellow3_ycor])


            distance_y2r2 = euclidean_distance([yellow2_xcor,yellow2_ycor],[red2_xcor,red2_ycor])
            distance_y2r4 = euclidean_distance([yellow2_xcor,yellow2_ycor],[red4_xcor,red4_ycor])
            distance_y3r3 = euclidean_distance([yellow3_xcor,yellow3_ycor],[red3_xcor,red3_ycor])
            distance_y3r4 = euclidean_distance([yellow3_xcor,yellow3_ycor],[red4_xcor,red4_ycor])
            distance_y1r1 = euclidean_distance([yellow1_xcor,yellow1_ycor],[red1_xcor,red1_ycor])
            distance_ar4 = euclidean_distance([270,350],[red4_xcor,red4_ycor])
            distance_ar3 = euclidean_distance([270,350],[red3_xcor,red3_ycor])
            distance_ar2 = euclidean_distance([270,350],[red2_xcor,red2_ycor])
            print("...100% completed")
            print("Checking player availability.......")
            try:
                if distance_y2r2 < 50 or is_collision(red2_xcor,red2_ycor, yellow2_xcor, yellow2_ycor, 300,20) and is_collision(red1_xcor,red1_ycor, yellow2_xcor, yellow2_ycor, 300,20) and is_collision(red4_xcor,red4_ycor, yellow2_xcor, yellow2_ycor, 300,20) :
                    y2_available=True
                   # pygame.draw.rect(display_surface, GREEN, pygame.Rect(yellow2_xcor,yellow2_ycor, 60, 60),  2)
                    time.sleep(0.2)
                    pygame.display.flip()
                else:
                     y2_available= False
                    # pygame.draw.rect(display_surface, RED, pygame.Rect(yellow2_xcor,yellow2_ycor, 60, 60),  2)
                     time.sleep(0.2)
                     pygame.display.flip()

                if distance_y3r3 < 50 or (is_collision(red3_xcor,red3_ycor, yellow3_xcor, yellow3_ycor, 300,20) and is_collision(red1_xcor,red1_ycor, yellow3_xcor, yellow3_ycor, 300,20) and is_collision(red4_xcor,red4_ycor, yellow3_xcor, yellow3_ycor, 300,20)):
                    y3_available=True
                   # pygame.draw.rect(display_surface, GREEN, pygame.Rect(yellow3_xcor,yellow3_ycor, 60, 60),  2)
                    time.sleep(0.2)
                    pygame.display.flip()
                else:
                    #pygame.draw.rect(display_surface, RED, pygame.Rect(yellow3_xcor,yellow3_ycor, 60, 60),  2)
                    time.sleep(0.2)
                    pygame.display.flip()
                    y3_available=False

                if(is_collision(red1_xcor,red1_ycor, yellow1_xcor, yellow1_ycor, 300,20)):
                    #pygame.draw.rect(display_surface, GREEN, pygame.Rect(yellow1_xcor,yellow1_ycor, 60, 60),  2)
                    time.sleep(0.2)
                    pygame.display.flip()
                    y1_available=True
                else:
                    #pygame.draw.rect(display_surface, RED, pygame.Rect(yellow1_xcor,yellow1_ycor, 60, 60),  2)
                    time.sleep(0.2)
                    pygame.display.flip()
                    y1_available=False
               
            except:
                pass

            #if(distance_ar4<50 or distance_ar3 <50 or distance_ar2<50):
                 #print("LOW CHANCE OF KICK  FROM CENTER")
                
            #else:a_available=True
             
            print("...100% completed")

            print("The Heuristic Cost is:")
            
            if (distance2+distance9)<(distance6+distance7) and (distance2+distance9)<(distance1+distance8) :
                print(distance2+distance9)
                if y3_available:
                     time.sleep(0.2)
                     display_surface.blit(img_ball, (yellow3_xcor+20,yellow3_ycor+20))
                     pygame.display.update()
                     pygame.draw.line(display_surface, (255,0,0), (280,370), (yellow3_xcor+20,yellow3_ycor+20))
                     time.sleep(0.2)
                     display_surface.blit(img_ball, (300,20))
                     pygame.display.update()
                     pygame.draw.line(display_surface, (255,0,0), (yellow3_xcor+20,yellow3_ycor+20), (300,20))

                else:
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow3_xcor+20,yellow3_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (280,370), (yellow3_xcor+20,yellow3_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow2_xcor+20,yellow2_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow2_xcor+20,yellow2_ycor+20), (yellow3_xcor+20,yellow3_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (300,20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow2_xcor+20,yellow2_ycor+20), (300,20))
                    
                    
            elif (distance1+distance8)<(distance2+distance9) and (distance6+distance7)>(distance1+distance8):
                print(distance1+distance8)
                if y2_available:
                     time.sleep(0.2)
                     display_surface.blit(img_ball, (yellow2_xcor+20,yellow2_ycor+20))
                     pygame.display.update()
                     pygame.draw.line(display_surface, (255,0,0), (280,370), (yellow2_xcor+10,yellow2_ycor+20))
                     time.sleep(0.2)
                     display_surface.blit(img_ball, (300,20))
                     pygame.display.update()
                     pygame.draw.line(display_surface, (255,0,0), (yellow2_xcor+20,yellow2_ycor+20), (300,20))
                else:
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow2_xcor+20,yellow2_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (280,370), (yellow2_xcor+20,yellow2_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow3_xcor+20,yellow3_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow2_xcor+20,yellow2_ycor+20), (yellow3_xcor+20,yellow3_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (300,20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow3_xcor+20,yellow3_ycor+20), (300,20))
                   
                    

            elif (distance6+distance7)<(distance2+distance9) and (distance6+distance7)<(distance1+distance8):
                print(distance6+distance7)
                if y1_available:
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow1_xcor+20,yellow1_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (280,370), (yellow1_xcor+20,yellow1_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (300,20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow1_xcor+20,yellow1_ycor+20), (300,20))
                else:
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow3_xcor+20,yellow3_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (280,370), (yellow3_xcor+20,yellow3_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (yellow2_xcor+20,yellow2_ycor+20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow2_xcor+20,yellow2_ycor+20), (yellow3_xcor+20,yellow3_ycor+20))
                        time.sleep(0.2)
                        display_surface.blit(img_ball, (300,20))
                        pygame.display.update()
                        pygame.draw.line(display_surface, (255,0,0), (yellow2_xcor+20,yellow2_ycor+20), (300,20))

            print("The 2nd lowest heuristic cost :")        
            if distance6+distance7<(distance1+distance8)and (distance6+distance7)<(distance2+distance9):
                
                if(distance1+distance8<(distance2+distance9)):
                    print(distance1+distance8)
                else:
                    print(distance2+distance9)
            elif (distance1+distance8)<(distance6+distance7)and (distance1+distance8)<(distance2+distance9):
                if(distance6+distance7)<distance2+distance9:
                    print(distance6+distance7)
                else:
                    print(distance2+distance9)

            else: 
                if distance6+distance7<distance1+distance8:
                    print(distance6+distance7)
                else:
                    print(distance1+distance8)           
    except:
        break    
      

    
  
    for event in pygame.event.get():  
        if event.type == pygame.QUIT:  
            pygame.quit()  
            # quit the program.   
            quit()  
        # Draws the surface object to the screen. 
        
        time.sleep(0.2)
        pygame.display.update()


